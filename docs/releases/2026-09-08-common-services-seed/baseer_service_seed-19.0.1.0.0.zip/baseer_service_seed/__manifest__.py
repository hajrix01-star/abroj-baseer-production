{
    'name': 'Baseer Common Services Seed',
    'summary': 'Company suppliers, service products and native expense mappings',
    'version': '19.0.1.0.0',
    'license': 'LGPL-3',
    'depends': ['baseer_company_setup', 'baseer_purchase_batch'],
    'data': ['data/categories.xml', 'data/setup.xml'],
    'installable': True,
}
