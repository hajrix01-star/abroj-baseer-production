from uuid import uuid4

from odoo import Command, fields
from odoo.exceptions import AccessError, UserError, ValidationError
from odoo.tests.common import TransactionCase


class RepresentativePettyCashCase(TransactionCase):
    """Focused accounting and workflow checks for PRA-BUILD-1 only."""

    def setUp(self):
        super().setUp()
        self.env.user.group_ids |= self.env.ref('baseer_procurement_requests.group_procurement_accountant')
        self.env.user.group_ids |= self.env.ref('baseer_procurement_requests.group_procurement_manager')
        self.env.user.group_ids |= self.env.ref('base.group_erp_manager')
        self.company = self.env.company
        self.company.currency_id.active = True
        self.warehouse = self.env['stock.warehouse'].search([('company_id', '=', self.company.id)], limit=1)
        category = self.env['product.category'].create({'name': 'Representative petty cash test category'})
        product = self.env['product.product'].create({
            'name': 'Representative petty cash test product', 'categ_id': category.id,
            'company_id': self.company.id,
        })
        self.option = self.env['baseer.procurement.purchase.option'].create({
            'name': 'Unit', 'company_id': self.company.id, 'product_id': product.id,
            'uom_id': product.uom_id.id,
        })
        self.representative = self.env['res.partner'].create({
            'name': 'Representative petty cash buyer', 'company_id': self.company.id,
        })
        self.representative.with_company(self.company).write({'is_purchase_representative': True})
        Account = self.env['account.account']
        self.petty_cash_account = Account.create({
            'name': 'Representative petty cash receivable', 'code': 'RPA701',
            'account_type': 'asset_receivable', 'reconcile': True,
            'company_ids': [Command.set(self.company.ids)],
        })
        cash_account = Account.create({
            'name': 'Representative petty cash bank', 'code': 'RPA702',
            'account_type': 'asset_cash', 'company_ids': [Command.set(self.company.ids)],
        })
        self.general_journal = self.env['account.journal'].create({
            'name': 'Representative petty cash entries', 'code': 'RPAG', 'type': 'general',
            'company_id': self.company.id,
        })
        self.bank_journal = self.env['account.journal'].create({
            'name': 'Representative petty cash bank', 'code': 'RPAB', 'type': 'bank',
            'company_id': self.company.id, 'default_account_id': cash_account.id,
        })
        self.company.write({
            'baseer_procurement_representative_petty_cash_account_id': self.petty_cash_account.id,
            'baseer_procurement_representative_petty_cash_journal_id': self.general_journal.id,
            'baseer_procurement_representative_petty_cash_payment_journal_ids': [Command.set([self.bank_journal.id])],
        })

    def _request(self):
        return self.env['baseer.procurement.request'].create({
            'company_id': self.company.id, 'warehouse_id': self.warehouse.id,
            'representative_partner_id': self.representative.id,
            'line_ids': [Command.create({
                'option_id': self.option.id, 'requested_qty': 5, 'requested_price': 4,
            })],
        })

    def _sent_request(self):
        request = self._request()
        request.action_mark_sent()
        return request

    def test_funding_posts_once_and_is_immutable(self):
        request = self._sent_request()
        token = str(uuid4())
        Model = self.env['baseer.procurement.representative.advance']
        record_id = Model.submit_funding(request.id, self.bank_journal.id, self.representative.id, 20, token, '2026-09-17')
        self.assertEqual(record_id, Model.submit_funding(request.id, self.bank_journal.id, self.representative.id, 20, token, '2026-09-17'))
        record = Model.browse(record_id)
        self.assertEqual(record.move_id.state, 'posted')
        self.assertEqual(record.amount, 20)
        self.assertEqual(str(record.movement_date), '2026-09-17')
        dashboard_movement = next(row for row in Model.dashboard_data()['movements'] if row['id'] == record.id)
        self.assertNotIn('external_reference', dashboard_movement)
        self.assertNotIn('proof_url', dashboard_movement)
        self.assertEqual(dashboard_movement['from_name'], self.bank_journal.display_name)
        self.assertEqual(dashboard_movement['to_name'], self.representative.display_name)
        line = record.move_id.line_ids.filtered(lambda row: row.account_id == self.petty_cash_account)
        self.assertEqual(line.baseer_representative_petty_cash_id, record)
        self.assertEqual(line.partner_id, self.representative)
        returned_id = Model.submit_return(record.id, self.bank_journal.id, 5, str(uuid4()))
        returned = Model.browse(returned_id)
        dashboard_return = next(row for row in Model.dashboard_data()['movements'] if row['id'] == returned.id)
        self.assertEqual(dashboard_return['from_name'], self.representative.display_name)
        self.assertEqual(dashboard_return['to_name'], self.bank_journal.display_name)
        self.assertEqual(record.remaining_amount, 15)
        returned_line = returned.move_id.line_ids.filtered(lambda row: row.account_id == self.petty_cash_account)
        self.assertEqual(returned_line.baseer_representative_petty_cash_id, record)
        self.assertTrue(returned_line.matched_debit_ids)
        with self.assertRaises(ValidationError):
            Model.submit_return(record.id, self.bank_journal.id, 16, str(uuid4()))
        with self.assertRaises(UserError):
            record.write({'amount': 10})
        with self.assertRaises(UserError):
            record.move_id.button_draft()

    def test_funding_rejects_draft_request_and_wrong_destination(self):
        request = self._request()
        Model = self.env['baseer.procurement.representative.advance']
        with self.assertRaises(ValidationError):
            Model.submit_funding(request.id, self.bank_journal.id, self.representative.id, 20, str(uuid4()), '2026-09-17')
        request.action_mark_sent()
        other = self.env['res.partner'].create({'name': 'Other representative', 'company_id': self.company.id})
        other.with_company(self.company).write({'is_purchase_representative': True})
        with self.assertRaises(ValidationError):
            Model.submit_funding(request.id, self.bank_journal.id, other.id, 20, str(uuid4()), '2026-09-17')

    def test_cashier_cannot_record_a_movement(self):
        request = self._sent_request()
        cashier = self.env['res.users'].create({
            'name': 'Representative petty cash cashier', 'login': 'representative-petty-cash-cashier',
            'group_ids': [Command.set([self.env.ref('baseer_procurement_requests.group_procurement_cashier').id])],
        })
        with self.assertRaises(AccessError):
            self.env['baseer.procurement.representative.advance'].with_user(cashier).submit_funding(
                request.id, self.bank_journal.id, self.representative.id, 20, str(uuid4()), '2026-09-17',
            )

    def test_manager_dashboard_is_read_only_without_payment_point_access(self):
        manager = self.env['res.users'].create({
            'name': 'Representative petty cash manager', 'login': 'representative-petty-cash-manager',
            'group_ids': [Command.set([self.env.ref('baseer_procurement_requests.group_procurement_manager').id])],
        })
        dashboard = self.env['baseer.procurement.representative.advance'].with_user(manager).dashboard_data()
        self.assertFalse(dashboard['can_record'])
        self.assertEqual(dashboard['payment_points'], [])

    def test_accountant_dashboard_lists_only_valid_company_payment_points(self):
        dashboard = self.env['baseer.procurement.representative.advance'].dashboard_data()
        self.assertIn(self.bank_journal.id, [point['id'] for point in dashboard['payment_points']])
        self.assertFalse(dashboard['setup_issue'])

    def test_dashboard_exposes_the_eligible_request_timestamp_without_changing_amount(self):
        request = self._sent_request()
        dashboard = self.env['baseer.procurement.representative.advance'].dashboard_data()
        row = next(item for item in dashboard['requests'] if item['id'] == request.id)
        self.assertEqual(row['request_date'], fields.Datetime.to_string(request.request_date))
        self.assertEqual(row['amount'], request.requested_total)
        self.assertEqual(row['representative_id'], self.representative.id)

    def test_dashboard_reports_missing_company_accounting_setup_before_save(self):
        self.company.baseer_procurement_representative_petty_cash_account_id = False
        dashboard = self.env['baseer.procurement.representative.advance'].dashboard_data()
        self.assertEqual(
            dashboard['setup_issue'],
            'Configure an active reconcilable Representative Petty Cash account first.',
        )

    def test_manager_initializes_one_shared_company_setup_without_payment_points(self):
        company = self.env['res.company'].create({
            'name': 'New representative petty cash company',
            'currency_id': self.company.currency_id.id,
        })
        payment_point_ids_before = company.baseer_procurement_representative_petty_cash_payment_journal_ids.ids

        # This is the real native completion event for a new company, not a
        # write simulation: the chart loader runs and our inherited hook then
        # creates the one shared account and general journal.
        self.env['account.chart.template']._load(
            self.company.chart_template, company, install_demo=False,
        )
        account = company.baseer_procurement_representative_petty_cash_account_id
        journal = company.baseer_procurement_representative_petty_cash_journal_id
        self.assertTrue(account.active)
        self.assertTrue(account.reconcile)
        self.assertEqual(account.account_type, 'asset_current')
        self.assertIn(company, account.company_ids)
        self.assertTrue(journal.active)
        self.assertEqual(journal.type, 'general')
        self.assertEqual(company.baseer_procurement_representative_petty_cash_payment_journal_ids.ids, payment_point_ids_before)

        company.action_baseer_initialize_representative_petty_cash()
        self.assertEqual(company.baseer_procurement_representative_petty_cash_account_id, account)
        self.assertEqual(company.baseer_procurement_representative_petty_cash_journal_id, journal)

        first = self.env['res.partner'].create({'name': 'First representative', 'company_id': company.id})
        second = self.env['res.partner'].create({'name': 'Second representative', 'company_id': company.id})
        first.with_company(company).is_purchase_representative = True
        second.with_company(company).is_purchase_representative = True
        self.assertEqual(company.baseer_procurement_representative_petty_cash_account_id, account)
        self.assertEqual(company.baseer_procurement_representative_petty_cash_journal_id, journal)

    def test_invalid_module_owned_seed_never_creates_the_other_setup_side(self):
        company = self.company
        company.write({
            'baseer_procurement_representative_petty_cash_account_id': False,
            'baseer_procurement_representative_petty_cash_journal_id': False,
        })
        company.action_baseer_initialize_representative_petty_cash()
        account = company.baseer_procurement_representative_petty_cash_account_id
        journal = company.baseer_procurement_representative_petty_cash_journal_id
        account.active = False
        company.write({
            'baseer_procurement_representative_petty_cash_account_id': False,
            'baseer_procurement_representative_petty_cash_journal_id': False,
        })
        with self.assertRaises(ValidationError):
            company.action_baseer_initialize_representative_petty_cash()
        self.assertFalse(company.baseer_procurement_representative_petty_cash_account_id)
        self.assertFalse(company.baseer_procurement_representative_petty_cash_journal_id)
        self.assertTrue(journal.exists())

    def test_manager_setup_does_not_complete_a_partial_manual_configuration(self):
        company = self.company
        account = self.env['account.account'].create({
            'name': 'Partial representative petty cash account', 'code': 'RPA80',
            'account_type': 'asset_current', 'reconcile': True,
            'company_ids': [Command.set(company.ids)],
        })
        company.write({
            'baseer_procurement_representative_petty_cash_account_id': account.id,
            'baseer_procurement_representative_petty_cash_journal_id': False,
        })
        with self.assertRaises(UserError):
            company.action_baseer_initialize_representative_petty_cash()
        self.assertEqual(company.baseer_procurement_representative_petty_cash_account_id, account)
        self.assertFalse(company.baseer_procurement_representative_petty_cash_journal_id)

    def test_only_erp_manager_can_initialize_company_setup(self):
        company = self.company
        accountant = self.env['res.users'].create({
            'name': 'Representative petty cash accountant setup',
            'login': 'representative-petty-cash-accountant-setup',
            'group_ids': [Command.set([
                self.env.ref('baseer_procurement_requests.group_procurement_accountant').id,
            ])],
        })
        with self.assertRaises(AccessError):
            company.with_user(accountant).action_baseer_initialize_representative_petty_cash()

    def test_only_configured_existing_payment_points_are_listed_and_accepted(self):
        other_cash_account = self.env['account.account'].create({
            'name': 'Other cash point', 'code': 'RPA703', 'account_type': 'asset_cash',
            'company_ids': [Command.set(self.company.ids)],
        })
        other_journal = self.env['account.journal'].create({
            'name': 'Unapproved cash point', 'code': 'RPAU', 'type': 'cash',
            'company_id': self.company.id, 'default_account_id': other_cash_account.id,
        })
        dashboard = self.env['baseer.procurement.representative.advance'].dashboard_data()
        self.assertEqual([point['id'] for point in dashboard['payment_points']], [self.bank_journal.id])
        request = self._sent_request()
        with self.assertRaises(ValidationError):
            self.env['baseer.procurement.representative.advance'].submit_funding(
                request.id, other_journal.id, self.representative.id, 20, str(uuid4()), '2026-09-17',
            )

    def test_system_administrator_can_review_dashboard(self):
        administrator = self.env.ref('base.user_admin')
        administrator.group_ids |= self.env.ref('base.group_system')
        dashboard = self.env['baseer.procurement.representative.advance'].with_user(administrator).dashboard_data()
        self.assertIn('summary', dashboard)

    def test_funding_requires_transfer_date(self):
        request = self._sent_request()
        Model = self.env['baseer.procurement.representative.advance']
        with self.assertRaises(ValidationError):
            Model.submit_funding(
                request.id, self.bank_journal.id, self.representative.id, 20, str(uuid4()), False,
            )
