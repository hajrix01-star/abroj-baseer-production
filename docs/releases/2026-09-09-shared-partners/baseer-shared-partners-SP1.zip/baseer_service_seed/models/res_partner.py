"""Optional bilingual supplier names; ordinary native contact editing remains intact."""
from odoo import api, fields, models


class Partner(models.Model):
    _inherit = 'res.partner'

    baseer_name_ar = fields.Char(string='Arabic Name', copy=False)
    baseer_name_en = fields.Char(string='English Name', copy=False)

    @api.onchange('baseer_name_ar', 'baseer_name_en')
    def _onchange_baseer_names(self):
        for record in self:
            name = ' | '.join(value.strip() for value in (record.baseer_name_ar, record.baseer_name_en) if value and value.strip())
            if name:
                record.name = name

    @api.model_create_multi
    def create(self, vals_list):
        clean = []
        for values in vals_list:
            values = dict(values)
            if {'baseer_name_ar', 'baseer_name_en'} & values.keys():
                name = ' | '.join(value.strip() for value in (values.get('baseer_name_ar'), values.get('baseer_name_en')) if value and value.strip())
                if name:
                    values['name'] = name
            clean.append(values)
        return super().create(clean)

    def write(self, values):
        if not {'baseer_name_ar', 'baseer_name_en'} & values.keys():
            return super().write(values)
        for record in self:
            changed = dict(values)
            name = ' | '.join(value.strip() for value in (
                changed.get('baseer_name_ar', record.baseer_name_ar),
                changed.get('baseer_name_en', record.baseer_name_en),
            ) if value and value.strip())
            if name:
                changed['name'] = name
            super(Partner, record).write(changed)
        return True
