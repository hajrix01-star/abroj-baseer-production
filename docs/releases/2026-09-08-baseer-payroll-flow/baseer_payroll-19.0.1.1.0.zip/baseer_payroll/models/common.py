"""Shared payroll boundaries: exact amounts, private transitions, employee locks."""
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
from odoo import _
from odoo.exceptions import AccessError, ValidationError

INTERNAL = object()
CENT = Decimal('0.01')

def decimal(value):
    try:
        result = Decimal(str(value or 0))
    except (InvalidOperation, ValueError):
        raise ValidationError(_('Enter a valid amount.'))
    if not result.is_finite():
        raise ValidationError(_('Enter a finite amount.'))
    return result

def money(value):
    return decimal(value).quantize(CENT, rounding=ROUND_HALF_UP)

def validate_money(value):
    value = decimal(value)
    if value != money(value) or value < 0:
        raise ValidationError(_('Amounts must be non-negative with at most two decimal places.'))
    return value

def require_manager(record):
    record.check_access('write')
    if not record.env.user.has_group('om_hr_payroll.group_hr_payroll_manager'):
        raise AccessError(_('Payroll manager access is required.'))
    companies = record.mapped('company_id') if 'company_id' in record._fields else record.env.company
    if any(c != record.env.company for c in companies):
        raise AccessError(_('Switch to the company that owns this record.'))

def lock_employee(env, employee_id, company_id):
    # Advisory key is stable across payroll, advances, repayments and allocations.
    env.cr.execute('SELECT pg_advisory_xact_lock(%s, %s)', (int(company_id), int(employee_id)))
