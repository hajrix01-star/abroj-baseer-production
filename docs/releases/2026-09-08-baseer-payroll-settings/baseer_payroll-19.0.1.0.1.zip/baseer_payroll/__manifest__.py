{
    'name': 'Baseer Payroll and Employee Advances',
    'version': '19.0.1.0.1',
    'license': 'LGPL-3',
    'depends': ['om_hr_payroll_account', 'hr_holidays', 'baseer_report_layout'],
    'data': [
        'security/security.xml', 'security/ir.model.access.csv',
        'views/payroll_views.xml', 'views/loan_views.xml',
        'views/settings_views.xml', 'report/payslip_report.xml',
    ],
    'assets': {'web.assets_backend': ['baseer_payroll/static/src/payroll.scss']},
    'installable': True,
}
