"""Read-only payroll stages/history derived from native payable reconciliations."""
from collections import defaultdict
from decimal import Decimal
from odoo import api, fields, models, _
from odoo.exceptions import UserError
from .common import money, decimal, require_manager


STAGES = [('draft', 'Draft'), ('awaiting', 'Awaiting Payment'),
          ('partial', 'Partially Paid'), ('paid', 'Fully Paid'), ('cancel', 'Canceled')]


def stage(state, net, remaining):
    if state == 'cancel':
        return 'cancel'
    if state not in ('done', 'close'):
        return 'draft'
    if money(remaining) <= 0:
        return 'paid'
    return 'partial' if money(remaining) < money(net) else 'awaiting'


def payments_action(payments):
    return {'type': 'ir.actions.act_window', 'name': _('Payment History'),
            'res_model': 'account.payment', 'view_mode': 'list,form',
            'domain': [('id', 'in', payments.ids)], 'context': {'create': False}}


class FinancialPayslip(models.Model):
    _inherit = 'hr.payslip'

    baseer_payment_state = fields.Selection(STAGES, compute='_compute_payment_stage', string='Payment Status')

    @api.depends('state', 'baseer_net', 'baseer_residual')
    def _compute_payment_stage(self):
        for slip in self:
            slip.baseer_payment_state = stage(slip.state, slip.baseer_net, slip.baseer_residual)

    def _baseer_payments(self):
        self.check_access('read')
        return self.move_id._get_reconciled_payments().filtered(lambda p: p.state in ('in_process', 'paid'))

    def action_view_payments(self):
        self.ensure_one()
        return payments_action(self._baseer_payments())

    def action_open_finance(self):
        self.ensure_one()
        self.check_access('read')
        return {'type': 'ir.actions.act_window', 'name': _('Financial Record'),
                'res_model': 'hr.payslip', 'res_id': self.id, 'view_mode': 'form',
                'views': [(self.env.ref('baseer_payroll.view_baseer_financial_payslip_form').id, 'form')]}

    def action_open_run(self):
        self.ensure_one()
        return self.payslip_run_id._baseer_open_run()


class FinancialEmployee(models.Model):
    _inherit = 'hr.employee'

    baseer_financial_slip_ids = fields.One2many(
        'hr.payslip', compute='_compute_financial_record', string='Financial Record',
        groups='om_hr_payroll.group_hr_payroll_manager', compute_sudo=False)

    @api.depends('slip_ids', 'slip_ids.baseer_managed', 'slip_ids.state')
    def _compute_financial_record(self):
        for employee in self:
            employee.baseer_financial_slip_ids = employee.slip_ids.filtered(
                lambda s: s.baseer_managed and s.company_id == employee.company_id and s.state != 'cancel'
            ).sorted(lambda s: (s.date_from, s.id), reverse=True)


class FinancialRun(models.Model):
    _inherit = 'hr.payslip.run'

    baseer_payment_state = fields.Selection(STAGES, compute='_compute_payment_stage', string='Payment Status')
    baseer_payment_count = fields.Integer(compute='_compute_payment_count', string='Payment History')

    @api.depends('state', 'baseer_net', 'baseer_residual')
    def _compute_payment_stage(self):
        for run in self:
            run.baseer_payment_state = stage(run.state, run.baseer_net, run.baseer_residual)

    def _compute_payment_count(self):
        for run in self:
            run.baseer_payment_count = len(run.slip_ids._baseer_payments())

    def _baseer_open_run(self):
        self.ensure_one()
        self.check_access('read')
        return {'type': 'ir.actions.act_window', 'name': self.name,
                'res_model': 'hr.payslip.run', 'res_id': self.id, 'view_mode': 'form',
                'views': [(self.env.ref('baseer_payroll.view_baseer_payroll_run_form').id, 'form')]}

    def action_pay(self):
        self.ensure_one()
        if not self.baseer_managed:
            return super().action_pay()
        require_manager(self)
        wizard = self.env['baseer.payroll.settlement'].create({'run_id': self.id})
        return {'type': 'ir.actions.act_window', 'name': _('Pay Salaries'),
                'res_model': wizard._name, 'res_id': wizard.id, 'view_mode': 'form', 'target': 'new',
                'views': [(self.env.ref('baseer_payroll.view_baseer_settlement_form').id, 'form')]}

    def action_view_payments(self):
        self.ensure_one()
        return payments_action(self.slip_ids._baseer_payments())

    def _baseer_payment_rows(self):
        self.ensure_one()
        self.check_access('read')
        rows = []
        labels = dict(self.env['account.payment']._fields['state']._description_selection(self.env))
        for slip in self.slip_ids.filtered(lambda s: s.state != 'cancel'):
            amounts = defaultdict(lambda: Decimal(0))
            payable = slip.move_id.line_ids.filtered(lambda line: line.account_id.account_type == 'liability_payable')
            for line in payable:
                for partial in line.matched_debit_ids | line.matched_credit_ids:
                    other = partial.debit_move_id if partial.credit_move_id == line else partial.credit_move_id
                    payment = other.move_id.origin_payment_id
                    if payment and payment.state in ('in_process', 'paid'):
                        amounts[payment] += decimal(partial.amount) * (1 if partial.credit_move_id == line else -1)
            for payment, amount in amounts.items():
                rows.append({'employee_name': slip.employee_id.name, 'date': fields.Date.to_string(payment.date),
                             'method': payment.journal_id.display_name, 'payment_name': payment.name,
                             'payment_id': payment.id, 'amount': float(money(amount)),
                             'state': labels[payment.state]})
        return sorted(rows, key=lambda row: (row['date'], row['payment_id'], row['employee_name']))

    def _baseer_payment_total(self):
        return float(money(sum((decimal(row['amount']) for row in self._baseer_payment_rows()), Decimal(0))))

    def action_print_payment_receipt(self):
        self.ensure_one()
        if not self._baseer_payment_rows():
            raise UserError(_('There are no recorded payments for this payroll.'))
        return self.env.ref('baseer_payroll.action_report_baseer_payment_receipt').report_action(self)
