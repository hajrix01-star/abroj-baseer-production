# Baseer Common Services Seed (CSS1)

Odoo 19 reusable, fill-only company setup. Depends on `baseer_company_setup`
and `baseer_purchase_batch`; neither dependency nor native code is modified.

## Result

* 20 company-private supplier contacts, 26 company-private service products,
  one native purchase-category mapping per selectable leaf.
* Shared Arabic category hierarchy and translated supplier tags, owned by
  stable XML IDs under `noupdate`. Existing categories are not renamed/moved.
* Expense accounts reuse valid native Saudi XML identities. Missing purposes
  receive a collision-safe dedicated expense account, shared by related services.
* Existing purchase/bank/cash journals remain authoritative; no service journals.
* Three published VAT values only: Saudi Energy, stc and Mobily. Other VAT fields
  are unknown/blank, not declarations of exemption. No default product taxes.
* Government entities and platforms have no forced supplier expense category.
  GOSI and ZATCA have contacts/tags only, not payment products or default expenses.

Company creation/chart-loading callbacks extend CAS1 after its native setup.
Module data initializes existing independent SAR companies with an existing chart.
Non-SAR companies are skipped because the current batch module requires SAR;
their country, currency and native accounting setup are not changed by CSS1.
Branches inherit native parent accounting policy and are not separately seeded.
The same-company row lock and MVCC conflict protect retryable concurrent calls;
no commits occur inside the seed. A transaction failure rolls back the seed.

`res.company._baseer_seed_services()` prepares a recordset; the model method
`_baseer_initialize_services()` prepares all eligible companies. Stable identities
are `<kind>_<key>_company_<id>` in this module for `provider`, `product`, `mapping`
and `account`. Catalog constants are `PROVIDERS`, `SERVICES`, `ACCOUNT_PURPOSES`.

Existing identity-owned records (including archived or renamed choices) are
preserved. Existing company/category mappings win. A single existing private
supplier matching the exact Arabic name or documented VAT can be adopted without
changing any fields. Multiple matches raise an actionable error; global shared
contacts are not adopted. A missing identity target raises instead of silently
recreating a deleted record. Existing VAT/tags/category preferences are not filled
or overwritten on adopted contacts.

## Rollback

Restore the verified database backup taken before installation and retain the
matching existing filestore when rolling back this seed. CSS1 creates no
attachments. **Do not use module uninstall as a rollback method.**
Stable XML IDs also identify adopted pre-existing suppliers or mappings. Odoo's
native uninstall treats these references as module-owned data and can attempt to
delete their records, including adopted masters that have no blocking references.
Uninstall is therefore not a preservation-safe reversal of this additive setup.

## Input and language behavior

Selecting a seeded leaf (including a supplier's default leaf) suggests Expense
on a new purchase-batch form; the user may change the type afterward. Backend
creation preserves any explicitly supplied `entry_type`, and only defaults a
missing type. Existing lines are never migrated or rewritten by setup.

Odoo category and contact names are not translated native fields; they use Arabic
display names. Contacts retain English/legacy search aliases in native `ref`.
Products use native translated names (English and active Arabic languages), and
supplier tags use native Arabic translation. No field schema is changed globally.

## Boundaries

This is master-data preparation, not HR service issuance/renewal, bills, payments,
payroll deductions, asset prepayments or amortization. Insurance products denote
expense classification only; posting an annual policy needs its actual accounting
treatment. Provider brands do not determine the legal invoice issuer or tax rate.
Platform subscription products do not represent every license/visa fee paid via
that platform. No final-exit product is provided. One Visas leaf/product is used;
later HR detail may distinguish issue/extension of exit-and-return.

Approved catalog/account/VAT evidence: repository documents
`COMMON-SERVICES-SEED.md`, `COMMON-SERVICES-SEED-GATE-REVIEW.md`, and
`COMMON-SERVICE-PARTIES-SEED-DECISIONS.md` dated 2026-09-08.
